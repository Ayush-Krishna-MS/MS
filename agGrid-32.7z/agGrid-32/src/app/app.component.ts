import { RouterOutlet } from '@angular/router';
import { Component } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular'; // Angular Data Grid Component
import { CellClickedEvent, GridApi, GridOptions, GridReadyEvent, RowNode, type ColDef } from 'ag-grid-community'; // Column Definition Type Interface


// Row Data Interface
interface IRow {
  make: string;
  model: string;
  price: number;
  electric: boolean;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [AgGridAngular],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  
  gridApi!:GridApi<IRow>;
  gridOptions!:GridOptions;

  constructor(){
    this.gridOptions=this.getGridOptions();
  }

  getGridOptions(){
    return {
      groupRowAggNodes:this.rowAggregator.bind(this),
      columnDefs: [
        { field: "make" },
        { field: "model" },
        { field: "price" },
        { field: "electric" },
      ],
      defaultColDef : {
        flex: 1,
      },
      onGridReady:this.onGridReady.bind(this)
    } as GridOptions
  }

  rowAggregator(nodes:RowNode[]){
    console.log(nodes);
    return 100;
  }

  onGridReady(ge:GridReadyEvent){
    console.log("grid ready",ge);
    this.gridApi=ge.api;
    this.gridApi.setGridOption('rowData',this.rowData);
  }

  onCellClicked(event:CellClickedEvent){
    console.log(event);
  }

  rowData: any[] = [
    { make: "Tesla", model: "Model Y", price: 64950, electric: true },
    { make: "Ford", model: "F-Series", price: 33850, electric: false },
    { make: "Toyota", model: "Corolla", price: 29600, electric: false },
    { make: "Mercedes", model: "EQA", price: 48890, electric: true },
    { make: "Fiat", model: "500", price: 15774, electric: false },
    { mak: "Nissan"  },
  ];

  // Column Definitions: Defines & controls grid columns.

  changeData(){

  }

}
